package ru.t1.school.open.logger;

public enum LoggingLevel implements LoggingCustomizer {
    SHORT,
    LONG
}
