package ru.t1.school.open.logger;

public interface LoggingCustomizer {
}
